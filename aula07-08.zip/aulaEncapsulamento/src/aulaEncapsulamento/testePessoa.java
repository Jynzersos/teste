package aulaEncapsulamento;

public class testePessoa {
	public static void main(String[] args) {
		Pessoa p1;
		p1 = new Pessoa();			

		p1.setNome("Mizael");
		p1.setEndereco("rua Austria");
		
		System.out.print("Nome: " + p1.getNome() + "\nEndereço: " + p1.getEndereco());
	}
}